Omnicasa integration for MODX

For detailed usage, please refer to the readme on GitHub: https://github.com/modmore/Omnicasa#readme
