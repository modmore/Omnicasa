<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'modmore\\Omnicasa\\Model',
    'namespacePrefix' => 'modmore\\Omnicasa',
    'class_map' => 
    array (
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'modmore\\Omnicasa\\Model\\ocProperty',
        ),
    ),
);