<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2022 modmore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Omnicasa integration for MODX

For detailed usage, please refer to the readme on GitHub: https://github.com/modmore/Omnicasa#readme
',
    'changelog' => 'Omnicasa 1.0.0-pl
------------------
Released on 2022-11-18

- First public release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '10ed19d46af9b8e4aa3ac99f2bed1c40',
      'native_key' => 'omnicasa',
      'filename' => 'MODX/Revolution/modNamespace/963e569571178bf8030eb554b0252985.vehicle',
      'namespace' => 'omnicasa',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '2a0ab89267d9fe6ee8fdca1a9588b984',
      'native_key' => '2a0ab89267d9fe6ee8fdca1a9588b984',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/9c8a1931d09da8698e4757344c161c9a.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'cf35d31ee3127ea0df87687a078523e8',
      'native_key' => 'cf35d31ee3127ea0df87687a078523e8',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/aa96c16aef2417c14f75909f6932fbe3.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'caea6ffb66838f98051c64c3fa120cac',
      'native_key' => 'omnicasa.customerName',
      'filename' => 'MODX/Revolution/modSystemSetting/60f6ec379ff17e61c965af57ecb47ef2.vehicle',
      'namespace' => 'omnicasa',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc12e6ec0db727048d124b5de0e8021a',
      'native_key' => 'omnicasa.customerPassword',
      'filename' => 'MODX/Revolution/modSystemSetting/758bf35d6c24720f02c34fc0e2486cf5.vehicle',
      'namespace' => 'omnicasa',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'd79903a6e93d8c8a0d3720d813341c46',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/145186cd36de3dacda24219bb9be86f0.vehicle',
      'namespace' => 'omnicasa',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '696b34ce66645c0e6af037f63d67fc73',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/a04c0573b0cd9c48fba6ebed5b259d87.vehicle',
      'namespace' => 'omnicasa',
    ),
  ),
);